// import React, { useState, useRef, useEffect } from "react";
// import { Link, useLocation } from "react-router-dom";
// import {
//   Moon,
//   Sun,
//   Menu,
//   X,
//   Phone,
//   Mail,
//   ChevronDown,
//   LogOut,
// } from "lucide-react";
// import { useTheme } from "../context/ThemeContext";
// import TestRideModal from "./Contact";

// const Header = () => {
//   const { isDarkMode, toggleTheme } = useTheme();
//   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   const [isContactModalOpen, setIsContactModalOpen] = useState(false);
//   const [isTestRideModalOpen, setIsTestRideModalOpen] = useState(false);
//   const [activeDropdown, setActiveDropdown] = useState(null);
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const location = useLocation();
//   const dropdownTimeoutRef = useRef(null);

//   // Check if user is logged in on component mount
//   useEffect(() => {
//     const token = localStorage.getItem("adminToken");
//     if (token) {
//       setIsLoggedIn(true);
//     }
//   });

//   // Navigation structure with dropdowns
//   const navItems = [
//     { name: "Home", path: "/" },
//     {
//       name: "Engineering",
//       path: "/engineering",
//       dropdown: [
//         { name: "Electrical", path: "/engineering/electrical" },
//         { name: "Mechanical", path: "/engineering/mechanical" },
//         { name: "Civil", path: "/engineering/civil" },
//         { name: "Electronics Communication", path: "/engineering/electronics" },
//       ],
//     },
//     {
//       name: "Higher Education",
//       path: "/higher-education",
//       dropdown: [
//         {
//           name: "Physics",
//           path: "/higher-education/physics",
//           subCategory: [
//             {
//               name: "Mechanics Thermal",
//               path: "/higher-education/physics/mechanics-thermal",
//             },
//             {
//               name: "Electricity & Magnetism Physics",
//               path: "/higher-education/physics/electricity-magnetism",
//             },
//             {
//               name: "Wave & Optics",
//               path: "/higher-education/physics/wave-optics",
//             },
//             {
//               name: "Analog Systems & Application",
//               path: "/higher-education/physics/analog-systems",
//             },
//             {
//               name: "Digital System",
//               path: "/higher-education/physics/digital-system",
//             },
//             {
//               name: "Element Of Modern Physics",
//               path: "/higher-education/physics/modern-physics",
//             },
//             {
//               name: "Quantum Mechanics Theory Lab",
//               path: "/higher-education/physics/quantum-mechanics",
//             },
//             {
//               name: "Solid State Physics",
//               path: "/higher-education/physics/solid-state",
//             },
//             {
//               name: "Electromagnetic",
//               path: "/higher-education/physics/electromagnetic",
//             },
//           ],
//         },
//         {
//           name: "Biotechnology",
//           path: "/higher-education/biotechnology",
//           subCategory: [
//             {
//               name: "Analytical",
//               path: "/higher-education/biotechnology/analytical",
//             },
//             {
//               name: "Heating And Cooling",
//               path: "/higher-education/biotechnology/heating-cooling-microscope",
//             },
//             {
//               name: "Microscope",
//               path: "/higher-education/biotechnology/microscope-techniques",
//             },
//           ],
//         },
//       ],
//     },
//     {
//       name: "School",
//       path: "/school",
//       dropdown: [
//         { name: "ATL", path: "/school/atl" },
//         { name: "STEM", path: "/school/steam" },
//       ],
//     },
//     {
//       name: "Skill Development",
//       path: "/skill-development",
//       dropdown: [
//         { name: "COE", path: "/skill-development/coe" },
//         { name: "IDEA LAB-PCB-3D", path: "/skill-development/idea-lab" },
//       ],
//     },
//     { name: "Furniture", path: "/furniture" },
//   ];

//   const handleMouseEnter = (itemName) => {
//     if (dropdownTimeoutRef.current) {
//       clearTimeout(dropdownTimeoutRef.current);
//     }
//     setActiveDropdown(itemName);
//   };

//   const handleMouseLeave = () => {
//     dropdownTimeoutRef.current = setTimeout(() => {
//       setActiveDropdown(null);
//     }, 150);
//   };

//   const handleDropdownMouseEnter = () => {
//     if (dropdownTimeoutRef.current) {
//       clearTimeout(dropdownTimeoutRef.current);
//     }
//   };

//   const handleDropdownMouseLeave = () => {
//     dropdownTimeoutRef.current = setTimeout(() => {
//       setActiveDropdown(null);
//     }, 150);
//   };

//   const handleLogout = (e) => {
//     // e.preventDefault();
//     localStorage.removeItem("adminToken");
//     localStorage.removeItem("adminEmail");
//     setIsLoggedIn(false);
//     // Optional: Redirect to home page after logout
//     window.location.href = "/";
//   };

//   useEffect(() => {
//     return () => {
//       if (dropdownTimeoutRef.current) {
//         clearTimeout(dropdownTimeoutRef.current);
//       }
//     };
//   }, []);

//   const renderDropdown = (item) => {
//     if (!item.dropdown) return null;

//     return (
//       <div
//         className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 z-50"
//         onMouseEnter={handleDropdownMouseEnter}
//         onMouseLeave={handleDropdownMouseLeave}
//       >
//         {item.dropdown.map((dropdownItem) => (
//           <div key={dropdownItem.name} className="relative group">
//             <Link
//               to={dropdownItem.path}
//               className="block px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 border-b border-gray-100 dark:border-gray-600 last:border-b-0"
//             >
//               <div className="flex items-center justify-between">
//                 <span>{dropdownItem.name}</span>
//                 {dropdownItem.subCategory && (
//                   <ChevronDown className="w-4 h-4 transform rotate-[-90deg]" />
//                 )}
//               </div>
//             </Link>

//             {/* Sub-categories for nested dropdowns */}
//             {dropdownItem.subCategory && (
//               <div className="absolute left-full top-0 ml-1 w-72 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
//                 <div className="p-2">
//                   <h4 className="font-semibold text-[#703233] dark:text-[#973E42] px-2 py-1 text-sm border-b border-gray-200 dark:border-gray-600 mb-2">
//                     {dropdownItem.name} Labs
//                   </h4>
//                   {dropdownItem.subCategory.map((subItem) => (
//                     <Link
//                       key={subItem.name}
//                       to={subItem.path}
//                       className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 rounded"
//                     >
//                       {subItem.name}
//                     </Link>
//                   ))}
//                 </div>
//               </div>
//             )}
//           </div>
//         ))}
//       </div>
//     );
//   };

//   return (
//     <>
//       <header className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm shadow-lg sticky top-0 z-40 transition-all duration-300">
//         <div className="">
//           {/* Top bar */}
//           <div className="bg-gradient-to-r from-[#703233] to-[#973E42] hidden md:flex justify-between items-center py-3 px-10 text-sm border-b border-gray-200 dark:border-gray-700">
//             <div className="flex items-center space-x-4">
//               <div className="flex items-center space-x-2">
//                 <Phone className="w-4 h-4 text-white" />
//                 <span className="text-white dark:text-gray-300">
//                   +91 9876543210
//                 </span>
//               </div>
//               <div className="flex items-center space-x-2">
//                 <Mail className="w-4 h-4 text-white" />
//                 <span className="text-white dark:text-gray-300">
//                   info@spancotek.com
//                 </span>
//               </div>
//             </div>
//             <button
//               onClick={toggleTheme}
//               className="p-2 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-800 transition-colors duration-200"
//               aria-label="Toggle theme"
//             >
//               {isDarkMode ? (
//                 <Sun className="w-4 h-4 text-white" />
//               ) : (
//                 <Moon className="w-4 h-4 text-white" />
//               )}
//             </button>
//           </div>

//           {/* Main header */}
//           <div className="flex justify-between items-center py-4 px-10">
//             <div className="flex items-center space-x-2 ">
//               <img
//                 className="max-w-[180px] md:max-w-[220px] h-auto object-contain"
//                 alt="Logo spancotek"
//                 src="/spanco-tek.png"
//               />
//             </div>

//             {/* Desktop Navigation */}
//             <nav className="hidden md:flex items-center space-x-8">
//               {navItems.map((item) => (
//                 <div
//                   key={item.name}
//                   className="relative"
//                   onMouseEnter={() => handleMouseEnter(item.name)}
//                   onMouseLeave={handleMouseLeave}
//                 >
//                   <Link
//                     to={item.name === "Contact" ? "#" : item.path}
//                     onClick={(e) => {
//                       if (item.name === "Contact") {
//                         e.preventDefault();
//                         setIsContactModalOpen(true);
//                       }
//                     }}
//                     className={`flex items-center space-x-1 text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium ${
//                       location.pathname === item.path && item.name !== "Contact"
//                         ? "text-[#703233] dark:text-[#973E42]"
//                         : ""
//                     }`}
//                   >
//                     <span>{item.name}</span>
//                     {item.dropdown && (
//                       <ChevronDown
//                         className={`w-4 h-4 transition-transform duration-200 ${
//                           activeDropdown === item.name ? "rotate-180" : ""
//                         }`}
//                       />
//                     )}
//                   </Link>

//                   {/* Dropdown Menu */}
//                   {activeDropdown === item.name && renderDropdown(item)}
//                 </div>
//               ))}
//             </nav>

//             <div className="flex items-center space-x-4">
//               {isLoggedIn ? (
//                 <button
//                   onClick={handleLogout}
//                   className="hidden md:flex items-center bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-all duration-200 font-medium text-sm"
//                 >
//                   <LogOut className="w-4 h-4 mr-1" />
//                   Logout
//                 </button>
//               ) : (
//                 <Link
//                   to="/login"
//                   className="hidden md:block bg-gray-800 dark:bg-gray-700 text-white px-4 py-2 rounded-lg hover:bg-gray-700 dark:hover:bg-gray-600 transition-all duration-200 font-medium text-sm"
//                 >
//                   Login
//                 </Link>
//               )}

//               <button
//                 onClick={() => setIsTestRideModalOpen(true)}
//                 className="hidden md:block bg-gradient-to-r from-[#703233] to-[#973E42] text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all duration-200 font-medium"
//               >
//                 Contact Us
//               </button>

//               {/* Mobile theme toggle */}
//               <button
//                 onClick={toggleTheme}
//                 className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
//                 aria-label="Toggle theme"
//               >
//                 {isDarkMode ? (
//                   <Sun className="w-5 h-5 text-yellow-500" />
//                 ) : (
//                   <Moon className="w-5 h-5 text-gray-600" />
//                 )}
//               </button>

//               {/* Mobile menu button */}
//               <button
//                 onClick={() => setIsMenuOpen(!isMenuOpen)}
//                 className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
//                 aria-label="Toggle menu"
//               >
//                 {isMenuOpen ? (
//                   <X className="w-6 h-6 text-gray-700 dark:text-gray-300" />
//                 ) : (
//                   <Menu className="w-6 h-6 text-gray-700 dark:text-gray-300" />
//                 )}
//               </button>
//             </div>
//           </div>

//           {/* Mobile Navigation */}
//           {isMenuOpen && (
//             <div className="md:hidden py-4 border-t border-gray-200 dark:border-gray-700">
//               <nav className="flex flex-col space-y-4 px-10">
//                 {navItems.map((item) => (
//                   <div key={item.name}>
//                     <Link
//                       to={item.name === "Contact" ? "#" : item.path}
//                       onClick={(e) => {
//                         if (item.name === "Contact") {
//                           e.preventDefault();
//                           setIsContactModalOpen(true);
//                         }
//                         if (!item.dropdown) {
//                           setIsMenuOpen(false);
//                         }
//                       }}
//                       className={`flex items-center justify-between text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium py-2 ${
//                         location.pathname === item.path &&
//                         item.name !== "Contact"
//                           ? "text-[#703233] dark:text-[#973E42]"
//                           : ""
//                       }`}
//                     >
//                       <span>{item.name}</span>
//                       {item.dropdown && <ChevronDown className="w-4 h-4" />}
//                     </Link>

//                     {/* Mobile dropdown items */}
//                     {item.dropdown && (
//                       <div className="ml-4 mt-2 space-y-2">
//                         {item.dropdown.map((dropdownItem) => (
//                           <div key={dropdownItem.name}>
//                             <Link
//                               to={dropdownItem.path}
//                               onClick={() => setIsMenuOpen(false)}
//                               className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#703233] dark:hover:text-[#973E42] py-1"
//                             >
//                               {dropdownItem.name}
//                             </Link>
//                             {/* Mobile sub-category */}
//                             {dropdownItem.subCategory && (
//                               <div className="ml-4 mt-1 space-y-1">
//                                 {dropdownItem.subCategory.map((subItem) => (
//                                   <Link
//                                     key={subItem.name}
//                                     to={subItem.path}
//                                     onClick={() => setIsMenuOpen(false)}
//                                     className="block text-xs text-gray-500 dark:text-gray-500 hover:text-[#703233] dark:hover:text-[#973E42] py-1"
//                                   >
//                                     {subItem.name}
//                                   </Link>
//                                 ))}
//                               </div>
//                             )}
//                           </div>
//                         ))}
//                       </div>
//                     )}
//                   </div>
//                 ))}

//                 {/* Mobile login/logout button */}
//                 {isLoggedIn ? (
//                   <button
//                     onClick={() => {
//                       handleLogout();
//                       setIsMenuOpen(false);
//                     }}
//                     className="flex items-center justify-center bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg transition-all duration-200 font-medium mt-4"
//                   >
//                     <LogOut className="w-4 h-4 mr-2" />
//                     Logout
//                   </button>
//                 ) : (
//                   <Link
//                     to="/login"
//                     onClick={() => setIsMenuOpen(false)}
//                     className="bg-gray-800 dark:bg-gray-700 text-white px-6 py-3 rounded-lg hover:bg-gray-700 dark:hover:bg-gray-600 transition-all duration-200 font-medium text-center mt-4"
//                   >
//                     Login
//                   </Link>
//                 )}

//                 <button
//                   onClick={() => {
//                     setIsTestRideModalOpen(true);
//                     setIsMenuOpen(false);
//                   }}
//                   className="bg-gradient-to-r from-[#703233] to-[#973E42] text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all duration-200 font-medium mt-4"
//                 >
//                   Contact Us
//                 </button>
//                 <h1>feff</h1>
//               </nav>
//             </div>
//           )}
//         </div>
//       </header>

//       <TestRideModal
//         isOpen={isTestRideModalOpen}
//         onClose={() => setIsTestRideModalOpen(false)}
//       />
//     </>
//   );
// };

// export default Header;

// import React, { useState, useRef, useEffect } from "react";
// import { Link, useLocation } from "react-router-dom";
// import {
//   Moon,
//   Sun,
//   Menu,
//   X,
//   Phone,
//   Mail,
//   ChevronDown,
//   LogOut,
// } from "lucide-react";
// import { useTheme } from "../context/ThemeContext";
// import TestRideModal from "./Contact";

// const Header = () => {
//   const { isDarkMode, toggleTheme } = useTheme();
//   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   const [isContactModalOpen, setIsContactModalOpen] = useState(false);
//   const [isTestRideModalOpen, setIsTestRideModalOpen] = useState(false);
//   const [activeDropdown, setActiveDropdown] = useState(null);
//   const [isLoggedIn, setIsLoggedIn] = useState(false);
//   const [categories, setCategories] = useState([]);
//   const [subcategories, setSubcategories] = useState([]);
//   const [labCategories, setLabCategories] = useState([]);
//   const location = useLocation();
//   const dropdownTimeoutRef = useRef(null);

//   // Check if user is logged in on component mount
//   useEffect(() => {
//     const token = localStorage.getItem("adminToken");
//     if (token) {
//       setIsLoggedIn(true);
//     }
//   }, []);

//   // Fetch all categories
//   useEffect(() => {
//     fetchCategories();
//   }, []);

//   const fetchCategories = () => {
//     fetch("http://localhost:5000/api/categories")
//       .then((res) => res.json())
//       .then((data) => {
//         setCategories(data);
//       })
//       .catch((err) => console.error("Error fetching categories:", err));
//   };

//   // Fetch subcategories when a category is hovered
//   const fetchSubcategories = (categoryId) => {
//     fetch(`http://localhost:5000/api/subcategories/category/${categoryId}`)
//       .then((res) => res.json())
//       .then((data) => {
//         setSubcategories((prev) => ({
//           ...prev,
//           [categoryId]: data,
//         }));
//       })
//       .catch((err) => console.error("Error fetching subcategories:", err));
//   };

//   // Fetch lab categories when a subcategory is hovered
//   const fetchLabCategories = (subcategoryId) => {
//     fetch(
//       `http://localhost:5000/api/labcategories/subcategory/${subcategoryId}`
//     )
//       .then((res) => res.json())
//       .then((data) => {
//         setLabCategories((prev) => ({
//           ...prev,
//           [subcategoryId]: data,
//         }));
//       })
//       .catch((err) => console.error("Error fetching lab categories:", err));
//   };

//   const handleMouseEnter = (itemName, categoryId = null) => {
//     if (dropdownTimeoutRef.current) {
//       clearTimeout(dropdownTimeoutRef.current);
//     }

//     setActiveDropdown(itemName);

//     // If it's a category with dropdown, fetch its subcategories
//     if (categoryId && !subcategories[categoryId]) {
//       fetchSubcategories(categoryId);
//     }
//   };

//   const handleMouseLeave = () => {
//     dropdownTimeoutRef.current = setTimeout(() => {
//       setActiveDropdown(null);
//     }, 150);
//   };

//   const handleDropdownMouseEnter = () => {
//     if (dropdownTimeoutRef.current) {
//       clearTimeout(dropdownTimeoutRef.current);
//     }
//   };

//   const handleDropdownMouseLeave = () => {
//     dropdownTimeoutRef.current = setTimeout(() => {
//       setActiveDropdown(null);
//     }, 150);
//   };

//   const handleSubcategoryMouseEnter = (subcategoryId) => {
//     if (dropdownTimeoutRef.current) {
//       clearTimeout(dropdownTimeoutRef.current);
//     }

//     // Fetch lab categories for this subcategory if not already loaded
//     if (subcategoryId && !labCategories[subcategoryId]) {
//       fetchLabCategories(subcategoryId);
//     }
//   };

//   const handleLogout = () => {
//     localStorage.removeItem("adminToken");
//     localStorage.removeItem("adminEmail");
//     setIsLoggedIn(false);
//     window.location.href = "/";
//   };

//   useEffect(() => {
//     return () => {
//       if (dropdownTimeoutRef.current) {
//         clearTimeout(dropdownTimeoutRef.current);
//       }
//     };
//   }, []);

//   const renderDropdown = (item) => {
//     if (!item.dropdown) return null;

//     return (
//       <div
//         className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 z-50"
//         onMouseEnter={handleDropdownMouseEnter}
//         onMouseLeave={handleDropdownMouseLeave}
//       >
//         {item.dropdown.map((dropdownItem) => (
//           <div
//             key={dropdownItem._id}
//             className="relative group"
//             onMouseEnter={() => handleSubcategoryMouseEnter(dropdownItem._id)}
//           >
//             <Link
//               to={`/category/${item._id}/subcategory/${dropdownItem._id}`}
//               className="block px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 border-b border-gray-100 dark:border-gray-600 last:border-b-0"
//             >
//               <div className="flex items-center justify-between">
//                 <span>{dropdownItem.name}</span>
//                 {dropdownItem.hasLabCategories && (
//                   <ChevronDown className="w-4 h-4 transform rotate-[-90deg]" />
//                 )}
//               </div>
//             </Link>

//             {/* Lab Categories for subcategories */}
//             {dropdownItem.hasLabCategories &&
//               labCategories[dropdownItem._id] && (
//                 <div className="absolute left-full top-0 ml-1 w-72 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
//                   <div className="p-2">
//                     <h4 className="font-semibold text-[#703233] dark:text-[#973E42] px-2 py-1 text-sm border-b border-gray-200 dark:border-gray-600 mb-2">
//                       {dropdownItem.name} Labs
//                     </h4>
//                     {labCategories[dropdownItem._id].map((labItem) => (
//                       <Link
//                         key={labItem._id}
//                         to={`/category/${item._id}/subcategory/${dropdownItem._id}/labcategory/${labItem._id}`}
//                         className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 rounded"
//                       >
//                         {labItem.name}
//                       </Link>
//                     ))}
//                   </div>
//                 </div>
//               )}
//           </div>
//         ))}
//       </div>
//     );
//   };

//   return (
//     <>
//       <header className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm shadow-lg sticky top-0 z-40 transition-all duration-300">
//         <div className="">
//           {/* Top bar */}
//           <div className="bg-gradient-to-r from-[#703233] to-[#973E42] hidden md:flex justify-between items-center py-3 px-10 text-sm border-b border-gray-200 dark:border-gray-700">
//             <div className="flex items-center space-x-4">
//               <div className="flex items-center space-x-2">
//                 <Phone className="w-4 h-4 text-white" />
//                 <span className="text-white dark:text-gray-300">
//                   +91 9876543210
//                 </span>
//               </div>
//               <div className="flex items-center space-x-2">
//                 <Mail className="w-4 h-4 text-white" />
//                 <span className="text-white dark:text-gray-300">
//                   info@spancotek.com
//                 </span>
//               </div>
//             </div>
//             <button
//               onClick={toggleTheme}
//               className="p-2 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-800 transition-colors duration-200"
//               aria-label="Toggle theme"
//             >
//               {isDarkMode ? (
//                 <Sun className="w-4 h-4 text-white" />
//               ) : (
//                 <Moon className="w-4 h-4 text-white" />
//               )}
//             </button>
//           </div>

//           {/* Main header */}
//           <div className="flex justify-between items-center py-4 px-10">
//             <div className="flex items-center space-x-2 ">
//               <Link to="/">
//                 <img
//                   className="max-w-[180px] md:max-w-[220px] h-auto object-contain"
//                   alt="Logo spancotek"
//                   src="/spanco-tek.png"
//                 />
//               </Link>
//             </div>

//             {/* Desktop Navigation */}
//             <nav className="hidden md:flex items-center space-x-8">
//               <Link
//                 to="/"
//                 className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium ${
//                   location.pathname === "/"
//                     ? "text-[#703233] dark:text-[#973E42]"
//                     : ""
//                 }`}
//               >
//                 Home
//               </Link>

//               {categories.map((category) => (
//                 <div
//                   key={category._id}
//                   className="relative"
//                   onMouseEnter={() =>
//                     handleMouseEnter(category._id, category._id)
//                   }
//                   onMouseLeave={handleMouseLeave}
//                 >
//                   <Link
//                     to={`/category/${category._id}`}
//                     className={`flex items-center space-x-1 text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium ${
//                       location.pathname === `/category/${category._id}`
//                         ? "text-[#703233] dark:text-[#973E42]"
//                         : ""
//                     }`}
//                   >
//                     <span>{category.name}</span>
//                     {subcategories[category._id] &&
//                       subcategories[category._id].length > 0 && (
//                         <ChevronDown
//                           className={`w-4 h-4 transition-transform duration-200 ${
//                             activeDropdown === category._id ? "rotate-180" : ""
//                           }`}
//                         />
//                       )}
//                   </Link>

//                   {/* Dropdown Menu for subcategories */}
//                   {activeDropdown === category._id &&
//                     subcategories[category._id] &&
//                     subcategories[category._id].length > 0 && (
//                       <div
//                         className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 z-50"
//                         onMouseEnter={handleDropdownMouseEnter}
//                         onMouseLeave={handleDropdownMouseLeave}
//                       >
//                         {subcategories[category._id].map((subcategory) => (
//                           <div
//                             key={subcategory._id}
//                             className="relative group"
//                             onMouseEnter={() =>
//                               handleSubcategoryMouseEnter(subcategory._id)
//                             }
//                           >
//                             <Link
//                               to={`/category/${category._id}/subcategory/${subcategory._id}`}
//                               className="block px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 border-b border-gray-100 dark:border-gray-600 last:border-b-0"
//                             >
//                               <div className="flex items-center justify-between">
//                                 <span>{subcategory.name}</span>
//                                 {subcategory.hasLabCategories && (
//                                   <ChevronDown className="w-4 h-4 transform rotate-[-90deg]" />
//                                 )}
//                               </div>
//                             </Link>

//                             {/* Lab Categories for subcategories */}
//                             {subcategory.hasLabCategories &&
//                               labCategories[subcategory._id] && (
//                                 <div className="absolute left-full top-0 ml-1 w-72 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
//                                   <div className="p-2">
//                                     <h4 className="font-semibold text-[#703233] dark:text-[#973E42] px-2 py-1 text-sm border-b border-gray-200 dark:border-gray-600 mb-2">
//                                       {subcategory.name} Labs
//                                     </h4>
//                                     {labCategories[subcategory._id].map(
//                                       (labCategory) => (
//                                         <Link
//                                           key={labCategory._id}
//                                           to={`/category/${category._id}/subcategory/${subcategory._id}/labcategory/${labCategory._id}`}
//                                           className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 rounded"
//                                         >
//                                           {labCategory.name}
//                                         </Link>
//                                       )
//                                     )}
//                                   </div>
//                                 </div>
//                               )}
//                           </div>
//                         ))}
//                       </div>
//                     )}
//                 </div>
//               ))}

//               <Link
//                 to="/furniture"
//                 className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium ${
//                   location.pathname === "/furniture"
//                     ? "text-[#703233] dark:text-[#973E42]"
//                     : ""
//                 }`}
//               >
//                 Furniture
//               </Link>
//             </nav>

//             <div className="flex items-center space-x-4">
//               {isLoggedIn ? (
//                 <button
//                   onClick={handleLogout}
//                   className="hidden md:flex items-center bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-all duration-200 font-medium text-sm"
//                 >
//                   <LogOut className="w-4 h-4 mr-1" />
//                   Logout
//                 </button>
//               ) : (
//                 <Link
//                   to="/login"
//                   className="hidden md:block bg-gray-800 dark:bg-gray-700 text-white px-4 py-2 rounded-lg hover:bg-gray-700 dark:hover:bg-gray-600 transition-all duration-200 font-medium text-sm"
//                 >
//                   Login
//                 </Link>
//               )}

//               <button
//                 onClick={() => setIsTestRideModalOpen(true)}
//                 className="hidden md:block bg-gradient-to-r from-[#703233] to-[#973E42] text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all duration-200 font-medium"
//               >
//                 Contact Us
//               </button>

//               {/* Mobile theme toggle */}
//               <button
//                 onClick={toggleTheme}
//                 className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
//                 aria-label="Toggle theme"
//               >
//                 {isDarkMode ? (
//                   <Sun className="w-5 h-5 text-yellow-500" />
//                 ) : (
//                   <Moon className="w-5 h-5 text-gray-600" />
//                 )}
//               </button>

//               {/* Mobile menu button */}
//               <button
//                 onClick={() => setIsMenuOpen(!isMenuOpen)}
//                 className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
//                 aria-label="Toggle menu"
//               >
//                 {isMenuOpen ? (
//                   <X className="w-6 h-6 text-gray-700 dark:text-gray-300" />
//                 ) : (
//                   <Menu className="w-6 h-6 text-gray-700 dark:text-gray-300" />
//                 )}
//               </button>
//             </div>
//           </div>

//           {/* Mobile Navigation */}
//           {isMenuOpen && (
//             <div className="md:hidden py-4 border-t border-gray-200 dark:border-gray-700">
//               <nav className="flex flex-col space-y-4 px-10">
//                 <Link
//                   to="/"
//                   onClick={() => setIsMenuOpen(false)}
//                   className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium py-2 ${
//                     location.pathname === "/"
//                       ? "text-[#703233] dark:text-[#973E42]"
//                       : ""
//                   }`}
//                 >
//                   Home
//                 </Link>

//                 {categories.map((category) => (
//                   <div key={category._id}>
//                     <Link
//                       to={`/category/${category._id}`}
//                       onClick={() => setIsMenuOpen(false)}
//                       className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium py-2 ${
//                         location.pathname === `/category/${category._id}`
//                           ? "text-[#703233] dark:text-[#973E42]"
//                           : ""
//                       }`}
//                     >
//                       {category.name}
//                     </Link>

//                     {/* Mobile subcategories */}
//                     {subcategories[category._id] && (
//                       <div className="ml-4 mt-2 space-y-2">
//                         {subcategories[category._id].map((subcategory) => (
//                           <div key={subcategory._id}>
//                             <Link
//                               to={`/category/${category._id}/subcategory/${subcategory._id}`}
//                               onClick={() => setIsMenuOpen(false)}
//                               className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#703233] dark:hover:text-[#973E42] py-1"
//                             >
//                               {subcategory.name}
//                             </Link>

//                             {/* Mobile lab categories */}
//                             {subcategory.hasLabCategories &&
//                               labCategories[subcategory._id] && (
//                                 <div className="ml-4 mt-1 space-y-1">
//                                   {labCategories[subcategory._id].map(
//                                     (labCategory) => (
//                                       <Link
//                                         key={labCategory._id}
//                                         to={`/category/${category._id}/subcategory/${subcategory._id}/labcategory/${labCategory._id}`}
//                                         onClick={() => setIsMenuOpen(false)}
//                                         className="block text-xs text-gray-500 dark:text-gray-500 hover:text-[#703233] dark:hover:text-[#973E42] py-1"
//                                       >
//                                         {labCategory.name}
//                                       </Link>
//                                     )
//                                   )}
//                                 </div>
//                               )}
//                           </div>
//                         ))}
//                       </div>
//                     )}
//                   </div>
//                 ))}

//                 <Link
//                   to="/furniture"
//                   onClick={() => setIsMenuOpen(false)}
//                   className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium py-2 ${
//                     location.pathname === "/furniture"
//                       ? "text-[#703233] dark:text-[#973E42]"
//                       : ""
//                   }`}
//                 >
//                   Furniture
//                 </Link>

//                 {/* Mobile login/logout button */}
//                 {isLoggedIn ? (
//                   <button
//                     onClick={() => {
//                       handleLogout();
//                       setIsMenuOpen(false);
//                     }}
//                     className="flex items-center justify-center bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg transition-all duration-200 font-medium mt-4"
//                   >
//                     <LogOut className="w-4 h-4 mr-2" />
//                     Logout
//                   </button>
//                 ) : (
//                   <Link
//                     to="/login"
//                     onClick={() => setIsMenuOpen(false)}
//                     className="bg-gray-800 dark:bg-gray-700 text-white px-6 py-3 rounded-lg hover:bg-gray-700 dark:hover:bg-gray-600 transition-all duration-200 font-medium text-center mt-4"
//                   >
//                     Login
//                   </Link>
//                 )}

//                 <button
//                   onClick={() => {
//                     setIsTestRideModalOpen(true);
//                     setIsMenuOpen(false);
//                   }}
//                   className="bg-gradient-to-r from-[#703233] to-[#973E42] text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all duration-200 font-medium mt-4"
//                 >
//                   Contact Us
//                 </button>
//               </nav>
//             </div>
//           )}
//         </div>
//       </header>

//       <TestRideModal
//         isOpen={isTestRideModalOpen}
//         onClose={() => setIsTestRideModalOpen(false)}
//       />
//     </>
//   );
// };

// export default Header;

import React, { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Moon,
  Sun,
  Menu,
  X,
  Phone,
  Mail,
  ChevronDown,
  LogOut,
} from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import TestRideModal from "./Contact";

const Header = () => {
  const { isDarkMode, toggleTheme } = useTheme();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isTestRideModalOpen, setIsTestRideModalOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState({});
  const [labCategories, setLabCategories] = useState({});
  const location = useLocation();
  const dropdownTimeoutRef = useRef(null);

  // Check if user is logged in on component mount
  useEffect(() => {
    const token = localStorage.getItem("adminToken");
    if (token) {
      setIsLoggedIn(true);
    }
  }, []);

  // Fetch all categories
  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = () => {
    fetch("http://localhost:5000/api/categories")
      .then((res) => res.json())
      .then((data) => {
        setCategories(data);
      })
      .catch((err) => console.error("Error fetching categories:", err));
  };

  // Fetch subcategories when a category is hovered
  const fetchSubcategories = (categoryId) => {
    fetch(`http://localhost:5000/api/subcategories/category/${categoryId}`)
      .then((res) => res.json())
      .then((data) => {
        setSubcategories((prev) => ({
          ...prev,
          [categoryId]: data,
        }));
      })
      .catch((err) => console.error("Error fetching subcategories:", err));
  };

  // Fetch lab categories when a subcategory is hovered
  const fetchLabCategories = (subcategoryId) => {
    fetch(
      `http://localhost:5000/api/labcategories/subcategory/${subcategoryId}`
    )
      .then((res) => res.json())
      .then((data) => {
        setLabCategories((prev) => ({
          ...prev,
          [subcategoryId]: data,
        }));
      })
      .catch((err) => console.error("Error fetching lab categories:", err));
  };

  const handleMouseEnter = (itemName, categoryId = null) => {
    if (dropdownTimeoutRef.current) {
      clearTimeout(dropdownTimeoutRef.current);
    }

    setActiveDropdown(itemName);

    // If it's a category with dropdown, fetch its subcategories
    if (categoryId && !subcategories[categoryId]) {
      fetchSubcategories(categoryId);
    }
  };

  const handleMouseLeave = () => {
    dropdownTimeoutRef.current = setTimeout(() => {
      setActiveDropdown(null);
    }, 150);
  };

  const handleDropdownMouseEnter = () => {
    if (dropdownTimeoutRef.current) {
      clearTimeout(dropdownTimeoutRef.current);
    }
  };

  const handleDropdownMouseLeave = () => {
    dropdownTimeoutRef.current = setTimeout(() => {
      setActiveDropdown(null);
    }, 150);
  };

  const handleSubcategoryMouseEnter = (subcategoryId) => {
    if (dropdownTimeoutRef.current) {
      clearTimeout(dropdownTimeoutRef.current);
    }

    // Fetch lab categories for this subcategory if not already loaded
    if (subcategoryId && !labCategories[subcategoryId]) {
      fetchLabCategories(subcategoryId);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    localStorage.removeItem("adminEmail");
    setIsLoggedIn(false);
    window.location.href = "/";
  };

  useEffect(() => {
    return () => {
      if (dropdownTimeoutRef.current) {
        clearTimeout(dropdownTimeoutRef.current);
      }
    };
  }, []);

  return (
    <>
      <header className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm shadow-lg sticky top-0 z-40 transition-all duration-300">
        <div className="">
          {/* Top bar */}
          <div className="bg-gradient-to-r from-[#703233] to-[#973E42] hidden md:flex justify-between items-center py-3 px-10 text-sm border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-white" />
                <span className="text-white dark:text-gray-300">
                  +91 9876543210
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-white" />
                <span className="text-white dark:text-gray-300">
                  info@spancotek.com
                </span>
              </div>
            </div>
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg hover:bg-gray-800 dark:hover:bg-gray-800 transition-colors duration-200"
              aria-label="Toggle theme"
            >
              {isDarkMode ? (
                <Sun className="w-4 h-4 text-white" />
              ) : (
                <Moon className="w-4 h-4 text-white" />
              )}
            </button>
          </div>

          {/* Main header */}
          <div className="flex justify-between items-center py-4 px-10">
            <div className="flex items-center space-x-2 ">
              <Link to="/">
                <img
                  className="max-w-[180px] md:max-w-[220px] h-auto object-contain"
                  alt="Logo spancotek"
                  src="/spanco-tek.png"
                />
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link
                to="/"
                className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium ${
                  location.pathname === "/"
                    ? "text-[#703233] dark:text-[#973E42]"
                    : ""
                }`}
              >
                Home
              </Link>

              {categories.map((category) => (
                <div
                  key={category._id}
                  className="relative"
                  onMouseEnter={() =>
                    handleMouseEnter(category._id, category._id)
                  }
                  onMouseLeave={handleMouseLeave}
                >
                  <Link
                    to={`/category/${category._id}`}
                    className={`flex items-center space-x-1 text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium ${
                      location.pathname === `/category/${category._id}`
                        ? "text-[#703233] dark:text-[#973E42]"
                        : ""
                    }`}
                  >
                    <span>{category.name}</span>
                    {subcategories[category._id] &&
                      subcategories[category._id].length > 0 && (
                        <ChevronDown
                          className={`w-4 h-4 transition-transform duration-200 ${
                            activeDropdown === category._id ? "rotate-180" : ""
                          }`}
                        />
                      )}
                  </Link>

                  {/* Dropdown Menu for subcategories */}
                  {activeDropdown === category._id &&
                    subcategories[category._id] &&
                    subcategories[category._id].length > 0 && (
                      <div
                        className="absolute left-0 top-full mt-1 w-64 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 z-50"
                        onMouseEnter={handleDropdownMouseEnter}
                        onMouseLeave={handleDropdownMouseLeave}
                      >
                        {subcategories[category._id].map((subcategory) => (
                          <div
                            key={subcategory._id}
                            className="relative group"
                            onClick={() =>
                              handleSubcategoryMouseEnter(subcategory._id)
                            }
                          >
                            <Link
                              to={`/category/${category._id}/subcategory/${subcategory._id}`}
                              className="block px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 border-b border-gray-100 dark:border-gray-600 last:border-b-0"
                            >
                              <div className="flex items-center justify-between">
                                <span>{subcategory.name}</span>
                                {labCategories[subcategory._id] &&
                                  labCategories[subcategory._id].length > 0 && (
                                    <ChevronDown className="w-4 h-4 transform rotate-[-90deg]" />
                                  )}
                              </div>
                            </Link>

                            {/* Lab Categories for subcategories */}
                            {labCategories[subcategory._id] &&
                              labCategories[subcategory._id].length > 0 && (
                                <div className="absolute left-full top-0 ml-1 w-72 bg-white dark:bg-gray-800 shadow-xl rounded-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                                  <div className="p-2">
                                    <h4 className="font-semibold text-[#703233] dark:text-[#973E42] px-2 py-1 text-sm border-b border-gray-200 dark:border-gray-600 mb-2">
                                      {subcategory.name} Labs
                                    </h4>
                                    {labCategories[subcategory._id].map(
                                      (labCategory) => (
                                        <Link
                                          key={labCategory._id}
                                          to={`/category/${category._id}/subcategory/${subcategory._id}/labcategory/${labCategory._id}`}
                                          className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 rounded"
                                        >
                                          {labCategory.name}
                                        </Link>
                                      )
                                    )}
                                  </div>
                                </div>
                              )}
                          </div>
                        ))}
                      </div>
                    )}
                </div>
              ))}

              <Link
                to="/furniture"
                className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium ${
                  location.pathname === "/furniture"
                    ? "text-[#703233] dark:text-[#973E42]"
                    : ""
                }`}
              >
                Furniture
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              {isLoggedIn ? (
                <button
                  onClick={handleLogout}
                  className="hidden md:flex items-center bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-all duration-200 font-medium text-sm"
                >
                  <LogOut className="w-4 h-4 mr-1" />
                  Logout
                </button>
              ) : (
                <Link
                  to="/login"
                  className="hidden md:block bg-gray-800 dark:bg-gray-700 text-white px-4 py-2 rounded-lg hover:bg-gray-700 dark:hover:bg-gray-600 transition-all duration-200 font-medium text-sm"
                >
                  Login
                </Link>
              )}

              <button
                onClick={() => setIsTestRideModalOpen(true)}
                className="hidden md:block bg-gradient-to-r from-[#703233] to-[#973E42] text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all duration-200 font-medium"
              >
                Contact Us
              </button>

              {/* Mobile theme toggle */}
              <button
                onClick={toggleTheme}
                className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
                aria-label="Toggle theme"
              >
                {isDarkMode ? (
                  <Sun className="w-5 h-5 text-yellow-500" />
                ) : (
                  <Moon className="w-5 h-5 text-gray-600" />
                )}
              </button>

              {/* Mobile menu button */}
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
                aria-label="Toggle menu"
              >
                {isMenuOpen ? (
                  <X className="w-6 h-6 text-gray-700 dark:text-gray-300" />
                ) : (
                  <Menu className="w-6 h-6 text-gray-700 dark:text-gray-300" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden py-4 border-t border-gray-200 dark:border-gray-700">
              <nav className="flex flex-col space-y-4 px-10">
                <Link
                  to="/"
                  onClick={() => setIsMenuOpen(false)}
                  className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium py-2 ${
                    location.pathname === "/"
                      ? "text-[#703233] dark:text-[#973E42]"
                      : ""
                  }`}
                >
                  Home
                </Link>

                {categories.map((category) => (
                  <div key={category._id}>
                    <Link
                      to={`/category/${category._id}`}
                      onClick={() => setIsMenuOpen(false)}
                      className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium py-2 ${
                        location.pathname === `/category/${category._id}`
                          ? "text-[#703233] dark:text-[#973E42]"
                          : ""
                      }`}
                    >
                      {category.name}
                    </Link>

                    {/* Mobile subcategories */}
                    {subcategories[category._id] && (
                      <div className="ml-4 mt-2 space-y-2">
                        {subcategories[category._id].map((subcategory) => (
                          <div key={subcategory._id}>
                            <Link
                              to={`/category/${category._id}/subcategory/${subcategory._id}`}
                              onClick={() => setIsMenuOpen(false)}
                              className="block text-sm text-gray-600 dark:text-gray-400 hover:text-[#703233] dark:hover:text-[#973E42] py-1"
                            >
                              {subcategory.name}
                            </Link>

                            {/* Mobile lab categories */}
                            {labCategories[subcategory._id] &&
                              labCategories[subcategory._id].length > 0 && (
                                <div className="ml-4 mt-1 space-y-1">
                                  {labCategories[subcategory._id].map(
                                    (labCategory) => (
                                      <Link
                                        key={labCategory._id}
                                        to={`/category/${category._id}/subcategory/${subcategory._id}/labcategory/${labCategory._id}`}
                                        onClick={() => setIsMenuOpen(false)}
                                        className="block text-xs text-gray-500 dark:text-gray-500 hover:text-[#703233] dark:hover:text-[#973E42] py-1"
                                      >
                                        {labCategory.name}
                                      </Link>
                                    )
                                  )}
                                </div>
                              )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}

                <Link
                  to="/furniture"
                  onClick={() => setIsMenuOpen(false)}
                  className={`text-gray-700 dark:text-gray-300 hover:text-[#703233] dark:hover:text-[#973E42] transition-colors duration-200 font-medium py-2 ${
                    location.pathname === "/furniture"
                      ? "text-[#703233] dark:text-[#973E42]"
                      : ""
                  }`}
                >
                  Furniture
                </Link>

                {/* Mobile login/logout button */}
                {isLoggedIn ? (
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                    className="flex items-center justify-center bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg transition-all duration-200 font-medium mt-4"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </button>
                ) : (
                  <Link
                    to="/login"
                    onClick={() => setIsMenuOpen(false)}
                    className="bg-gray-800 dark:bg-gray-700 text-white px-6 py-3 rounded-lg hover:bg-gray-700 dark:hover:bg-gray-600 transition-all duration-200 font-medium text-center mt-4"
                  >
                    Login
                  </Link>
                )}

                <button
                  onClick={() => {
                    setIsTestRideModalOpen(true);
                    setIsMenuOpen(false);
                  }}
                  className="bg-gradient-to-r from-[#703233] to-[#973E42] text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all duration-200 font-medium mt-4"
                >
                  Contact Us
                </button>
              </nav>
            </div>
          )}
        </div>
      </header>

      <TestRideModal
        isOpen={isTestRideModalOpen}
        onClose={() => setIsTestRideModalOpen(false)}
      />
    </>
  );
};

export default Header;
